package DAO;


import java.sql.*;
import java.util.ArrayList;

public class AtendimentoDAO {
    private Connection conexao = null; 
    
    public AtendimentoDAO(){
        String url = "jdbc:mysql://localhost/db_ohmydog"; 
        String usuario = "root";
        String senha = "";
        
        try {
            conexao = DriverManager.getConnection(url, usuario, senha);
            System.out.println("Conexao com o banco de dados realizada com sucesso");
        } catch (SQLException e) {
            System.out.println("Erro na conexao com o banco: "+e);
        }
    }
    
    //metodo para adicionar o paciente no banco de dados
    public void adicionar(Cadastros.Atendimentos c){
        String insercao = "insert into atendimentos(horario, dia, servico, fk_id, fk_fk_cpf) values (?,?,?,?,?)";
        PreparedStatement stmt;
        try{
            stmt = conexao.prepareStatement(insercao);
            stmt.setString(1, c.getHorario());
            stmt.setString(2, c.getDia());
            stmt.setString(3, c.getServico());
            stmt.setInt(4, c.getFk_id());
            stmt.setString(5, c.getFk_fk_cpf());
            stmt.execute();            
            System.out.println("Atendimento agendado com sucesso.");

        }catch(SQLException e){
            System.out.println("Erro na insercao dos dados: "+e);
        } 
    }
        
    public void remover(String str){
        String remocao;
        PreparedStatement stmt;
        try{
            
            remocao = "delete from atendimentos where horario = ?";
            stmt = conexao.prepareStatement(remocao);
            stmt.setString(1, str);
            stmt.execute();            
            
            


            System.out.println("Cliente removido com sucesso.");

        }catch(SQLException e){
            System.out.println("Erro na insercao dos dados: "+e);
        } 
    }
    
    
    public String[] listarNomes(){
        ArrayList<Cadastros.Animal> animal_a = new ArrayList<>();
        String consulta = "select * from animais";
        try{
            PreparedStatement stmt = conexao.prepareStatement(consulta);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()){
                Cadastros.Animal p = new Cadastros.Animal(rs.getString("nome"), rs.getInt("id"), rs.getString("fk_cpf"));
                animal_a.add(p);
            }

        }catch(SQLException e){
            System.out.println("Erro na consulta dos dados: "+e);
        }
        String[] finalList = new String[animal_a.size()];
        
        for(int i = 0 ; i < animal_a.size() ; i ++)
        {
            finalList[i] = animal_a.get(i).getId() + " - " + animal_a.get(i).getNome() + " - " + animal_a.get(i).getFk_cpf();
        }
        
        return finalList;
    }
    
    
    
    
    //retornar, como ArrayList, todos os pacientes cadastrados
    public ArrayList<Cadastros.Atendimentos> consultarTodos(){
        ArrayList<Cadastros.Atendimentos> atendimento_a = new ArrayList<>();
        String consulta = "select * from atendimentos";
        try{
            PreparedStatement stmt = conexao.prepareStatement(consulta);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()){
                Cadastros.Atendimentos p = new Cadastros.Atendimentos(rs.getString("horario"), rs.getString("dia"), rs.getString("servico"), rs.getInt("fk_id"), rs.getString("fk_fk_cpf"));
                atendimento_a.add(p);
            }

        }catch(SQLException e){
            System.out.println("Erro na consulta dos dados: "+e);
        }
        return atendimento_a;
    }
}
