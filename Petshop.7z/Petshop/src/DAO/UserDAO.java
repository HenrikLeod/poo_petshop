package DAO;

import java.sql.*;
import java.util.ArrayList;

public class UserDAO {
    private Connection conexao = null; 
    
    public UserDAO(){
        String url = "jdbc:mysql://localhost/db_ohmydog"; 
        String usuario = "root";
        String senha = "";
        try {
            conexao = DriverManager.getConnection(url, usuario, senha);
            System.out.println("Conexao com o banco de dados realizada com sucesso");
        } catch (SQLException e) {
            System.out.println("Erro na conexao com o banco: "+e);
        }
    }
    
    //metodo para adicionar o paciente no banco de dados
    public void adicionar(Auth.User p){
        String insercao = "insert into usuarios(nome, senha) values (?,?)";
        PreparedStatement stmt = null;
        try{
            stmt = conexao.prepareStatement(insercao);
            stmt.setString(1, p.getUsuario());
            stmt.setString(2, p.getSenha());
            stmt.execute();            
            System.out.println("Usuario cadastrado com sucesso.");

        }catch(SQLException e){
            System.out.println("Erro na insercao dos dados: "+e);
        } 
    }
        
    //retornar, como ArrayList, todos os pacientes cadastrados
    public ArrayList<Auth.User> consultarTodos(){
        ArrayList<Auth.User> user_a = new ArrayList<>();
        String consulta = "select * from usuarios";
        try{
            PreparedStatement stmt = conexao.prepareStatement(consulta);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()){
                Auth.User p = new Auth.User(rs.getString("nome"), rs.getString("senha"));
                user_a.add(p);
            }

        }catch(SQLException e){
            System.out.println("Erro na consulta dos dados: "+e);
        }
        return user_a;
    }
}
