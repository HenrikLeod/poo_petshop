/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cadastros;

/**
 *
 * @author Leod
 */
public class Animal {
    private String nome;
    private String tipo;
    private String sexo;
    private String fk_cpf;
    private int id;
    
    public Animal(String nome, int id, String fk_cpf)
    {
        this.nome = nome;
        this.id   = id;
        this.fk_cpf = fk_cpf;
    }
    public Animal(String nome, String tipo, String sexo, String fk_cpf, int id)
    {
        this.nome = nome;
        this.tipo = tipo;
        this.sexo = sexo;
        this.fk_cpf = fk_cpf;
        this.id = id;
    }
    
    public Animal(String nome, String tipo, String sexo, String fk_cpf)
    {
        this.nome = nome;
        this.tipo = tipo;
        this.sexo = sexo;
        this.fk_cpf = fk_cpf;
      
    }
    
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getFk_cpf() {
        return fk_cpf;
    }

    public void setFk_cpf(String fk_cpf) {
        this.fk_cpf = fk_cpf;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    
}
