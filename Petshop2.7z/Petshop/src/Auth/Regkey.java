/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Auth;

/**
 *
 * @author Leod
 */
public class Regkey {
    private String regKey = "IFAL-MFPL-IDV2-H264";

    public String getRegKey() {
        return regKey;
    }

    public void setRegKey(String regKey) {
        this.regKey = regKey;
    }
    
    
}
