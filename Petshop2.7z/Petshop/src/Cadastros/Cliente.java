/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cadastros;

/**
 *
 * @author Leod
 */
public class Cliente {
    private String nome;
    private String cpf;
    private String telefone;
    private String sexo;

    
    public Cliente(String nome, String cpf, String telefone, String sexo)
    {
        this.nome = nome;
        this.cpf  = cpf;
        this.telefone = telefone;
        this.sexo = sexo;
    }
    
    public Cliente(String nome, String cpf)
    {
        this.nome = nome;
        this.cpf = cpf;
    }
    
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }
    

    
    @Override
    public String toString()
    {
        return "Nome: " + nome + " | CPF: " + cpf + "| Telefone: " + telefone + "| Sexo: " + sexo;
    }
    
    public Object[] linhaArrayList = {nome, cpf, telefone, sexo};
}
