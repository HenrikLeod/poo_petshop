/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cadastros;

/**
 *
 * @author Alyne
 */
public class Atendimentos {
    private String horario;
    private String dia;
    private String servico;
    private int fk_id;
    private String fk_fk_cpf;

    public Atendimentos(String horario, String dia, String servico, int fk_id, String fk_fk_cpf)
    {
        this.horario = horario;
        this.dia = dia;
        this.servico = servico;
        this.fk_id = fk_id;
        this.fk_fk_cpf = fk_fk_cpf;
    }
    
    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public String getServico() {
        return servico;
    }

    public void setServico(String servico) {
        this.servico = servico;
    }

    public int getFk_id() {
        return fk_id;
    }

    public void setFk_id(int fk_id) {
        this.fk_id = fk_id;
    }

    public String getFk_fk_cpf() {
        return fk_fk_cpf;
    }

    public void setFk_fk_cpf(String fk_fk_cpf) {
        this.fk_fk_cpf = fk_fk_cpf;
    }
    
}
