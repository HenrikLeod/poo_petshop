/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Janelas;

import DAO.*;
import Cadastros.*;
import java.awt.Image;
import java.awt.Toolkit;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Leod
 */
public class C_Principal extends javax.swing.JFrame {

    /**
     * Creates new form C_Principal
     */

    
    public C_Principal() {
        initComponents();
       
        //parâmetros de redomensionamento e posição na tela
        this.setResizable(false);
        this.setLocationRelativeTo(null);
        
        //ícone do JFrame
        URL url = this.getClass().getResource("/Imagens/pataIcon.png");  
        Image iconeTitulo = Toolkit.getDefaultToolkit().getImage(url);  
        this.setIconImage(iconeTitulo);
        
        //atualizar listas de clientes e animais na inicialização (para manter a comboBox e a jtable atualizada)
        atualizarListaDeClientes();
        atualizarListaDeAnimais();
        atualizarReservas();
        
        
    }

    
    private void atualizarListaDeClientes()
    {
        //carregar clientes 
        
        ClienteDAO cdao = new ClienteDAO();
        String[] obj = cdao.listarNomes();
        
        Arrays.sort(obj);
        if(obj == null)
        {
            comboDonos.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] {"<nenhum>"}));
            cadastrarAnimalBtn.setEnabled(false);
        }
        else
        {
            //popular comboBox
            comboDonos.setModel(new javax.swing.DefaultComboBoxModel<>(obj));
            cadastrarAnimalBtn.setEnabled(true);
            
            //popular tabela
            ArrayList <Cliente> al_c = cdao.consultarTodos();
            Collections.sort(al_c,
                 new Comparator<Cliente>()
                 {
                     public int compare(Cliente p1, Cliente p2)
                     {
                         return p1.getNome().compareTo(p2.getNome());
                     }        
                 });
            DefaultTableModel modelo_c = (DefaultTableModel) listarClientes_t.getModel();
           
            modelo_c.setNumRows(0);
            
            //inserir linhas na tabela
            for(int i = 0 ; i < al_c.size() ; i ++)
            {
               modelo_c.addRow(new Object[] {al_c.get(i).getNome(), al_c.get(i).getCpf(), al_c.get(i).getTelefone(), al_c.get(i).getSexo()});
            }
        }
    }
    
    private void atualizarListaDeAnimais()
    {
        //carregar clientes 
        
        AnimalDAO adao = new AnimalDAO();
        String[] obj = adao.listarNomes();
        
        Arrays.sort(obj);
        if(obj == null)
        {
            comboAnimal.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] {"<nenhum>"}));
            reservarBtn.setEnabled(false);
        }
        else
        {
            //popular comboBox
            comboAnimal.setModel(new javax.swing.DefaultComboBoxModel<>(obj));
            reservarBtn.setEnabled(true);
            
            //popular tabela
            ArrayList <Animal> al_a = adao.consultarTodos();
            
            Collections.sort(al_a,
                 new Comparator<Animal>()
                 {
                     public int compare(Animal p1, Animal p2)
                     {
                         return p1.getNome().compareTo(p2.getNome());
                     }        
                 });
            DefaultTableModel modelo_a = (DefaultTableModel) listarAnimais_t.getModel();
           
            modelo_a.setNumRows(0);
            
            //inserir linhas na tabela
            for(int i = 0 ; i < al_a.size() ; i ++)
            {
               modelo_a.addRow(new Object[] {al_a.get(i).getNome(), al_a.get(i).getTipo(), al_a.get(i).getSexo(), al_a.get(i).getFk_cpf(), al_a.get(i).getId()});
            }
        }
    }
    
    
    private void atualizarReservas()
    {
        
        AtendimentoDAO atdao = new AtendimentoDAO();
        String[] obj = atdao.listarNomes();
        
        Arrays.sort(obj);
        //carregar clientes 
        
        if(obj == null)
        {
            comboAnimal.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] {"<nenhum>"}));
            reservarBtn.setEnabled(false);
        }
        else
        {
            //popular comboBox
            comboAnimal.setModel(new javax.swing.DefaultComboBoxModel<>(obj));
            reservarBtn.setEnabled(true);
        }
        
            //popular tabela
            ArrayList <Atendimentos> al_at = atdao.consultarTodos();
            
            Collections.sort(al_at,
                 new Comparator<Atendimentos>()
                 {
                     public int compare(Atendimentos p1, Atendimentos p2)
                     {
                         return p1.getHorario().compareTo(p2.getHorario());
                     }        
                 });
            DefaultTableModel modelo_a = (DefaultTableModel) listarReservas_t.getModel();
           
            modelo_a.setNumRows(0);
            
            //inserir linhas na tabela
            for(int i = 0 ; i < al_at.size() ; i ++)
            {
               modelo_a.addRow(new Object[] {al_at.get(i).getHorario(), al_at.get(i).getDia(), al_at.get(i).getServico(), al_at.get(i).getFk_id(), al_at.get(i).getFk_fk_cpf()});
            }
    }
        
    
    private void resetar()
    {
        nome_c_f.setText("");
        cpf_c_f.setText("");
        tel_c_f.setText("");
        sexo_c_f.setSelectedIndex(0);
        nome_a_f.setText("");
        tipo_a_f.setSelectedIndex(0);
        sexo_a_f.setSelectedIndex(0);
        comboDonos.setSelectedIndex(0);
        horario_r_f.setText("");
        dia_r_f.setSelectedIndex(0);
        servico_r_f.setSelectedIndex(0);
        comboAnimal.setSelectedIndex(0);
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        loginLabel = new javax.swing.JLabel();
        sairB = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jPanel6 = new javax.swing.JPanel();
        nome_c_f = new javax.swing.JTextField();
        userLabel = new javax.swing.JLabel();
        userLabel1 = new javax.swing.JLabel();
        cpf_c_f = new javax.swing.JFormattedTextField();
        tel_c_f = new javax.swing.JFormattedTextField();
        userLabel2 = new javax.swing.JLabel();
        sexo_c_f = new javax.swing.JComboBox<String>();
        userLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        loginLabel1 = new javax.swing.JLabel();
        feed = new javax.swing.JLabel();
        cadastrarClienteBtn = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jPanel17 = new javax.swing.JPanel();
        nome_a_f = new javax.swing.JTextField();
        userLabel4 = new javax.swing.JLabel();
        userLabel5 = new javax.swing.JLabel();
        userLabel6 = new javax.swing.JLabel();
        tipo_a_f = new javax.swing.JComboBox<String>();
        userLabel7 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        loginLabel2 = new javax.swing.JLabel();
        feed1 = new javax.swing.JLabel();
        cadastrarAnimalBtn = new javax.swing.JButton();
        sexo_a_f = new javax.swing.JComboBox<String>();
        comboDonos = new javax.swing.JComboBox<String>();
        jPanel5 = new javax.swing.JPanel();
        jPanel18 = new javax.swing.JPanel();
        userLabel8 = new javax.swing.JLabel();
        userLabel9 = new javax.swing.JLabel();
        userLabel10 = new javax.swing.JLabel();
        dia_r_f = new javax.swing.JComboBox<String>();
        userLabel11 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        loginLabel3 = new javax.swing.JLabel();
        reservarBtn = new javax.swing.JButton();
        servico_r_f = new javax.swing.JComboBox<String>();
        comboAnimal = new javax.swing.JComboBox<String>();
        horario_r_f = new javax.swing.JFormattedTextField();
        jPanel9 = new javax.swing.JPanel();
        jPanel13 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        listarClientes_t = new javax.swing.JTable();
        removerClienteBtn = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jPanel19 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        listarAnimais_t = new javax.swing.JTable();
        removerAnimalBtn = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        jPanel20 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        listarReservas_t = new javax.swing.JTable();
        removerHorarioBtn = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        jPanel16 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 0, 0));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 82, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 470, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 470));

        jPanel2.setBackground(new java.awt.Color(204, 0, 0));

        loginLabel.setFont(new java.awt.Font("Segoe UI Light", 0, 36)); // NOI18N
        loginLabel.setForeground(new java.awt.Color(255, 255, 255));
        loginLabel.setText("Menu principal:");

        sairB.setFont(new java.awt.Font("Segoe UI Light", 0, 12)); // NOI18N
        sairB.setForeground(new java.awt.Color(255, 255, 255));
        sairB.setText("Sair");
        sairB.setBorderPainted(false);
        sairB.setContentAreaFilled(false);
        sairB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sairBActionPerformed(evt);
            }
        });

        jPanel6.setBackground(new java.awt.Color(204, 0, 0));

        nome_c_f.setBackground(new java.awt.Color(204, 0, 0));
        nome_c_f.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        nome_c_f.setForeground(new java.awt.Color(255, 255, 255));
        nome_c_f.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        nome_c_f.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                nome_c_fKeyReleased(evt);
            }
        });

        userLabel.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        userLabel.setForeground(new java.awt.Color(255, 255, 255));
        userLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        userLabel.setText("CPF:");

        userLabel1.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        userLabel1.setForeground(new java.awt.Color(255, 255, 255));
        userLabel1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        userLabel1.setText("Nome:");

        cpf_c_f.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        cpf_c_f.setForeground(new java.awt.Color(255, 255, 255));
        try {
            cpf_c_f.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###.###.###-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        cpf_c_f.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        cpf_c_f.setOpaque(false);

        tel_c_f.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        tel_c_f.setForeground(new java.awt.Color(255, 255, 255));
        try {
            tel_c_f.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("(##) #####-####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        tel_c_f.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        tel_c_f.setOpaque(false);

        userLabel2.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        userLabel2.setForeground(new java.awt.Color(255, 255, 255));
        userLabel2.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        userLabel2.setText("Telefone:");

        sexo_c_f.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        sexo_c_f.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Masculino", "Feminino", "Prefiro não responder" }));
        sexo_c_f.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        sexo_c_f.setOpaque(false);
        sexo_c_f.setRequestFocusEnabled(false);

        userLabel3.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        userLabel3.setForeground(new java.awt.Color(255, 255, 255));
        userLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        userLabel3.setText("Sexo:");

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/icons8-customer-filled-100.png"))); // NOI18N

        loginLabel1.setFont(new java.awt.Font("Segoe UI Light", 0, 36)); // NOI18N
        loginLabel1.setForeground(new java.awt.Color(255, 255, 255));
        loginLabel1.setText("Novo cliente: ");

        feed.setFont(new java.awt.Font("Segoe UI Light", 0, 24)); // NOI18N
        feed.setForeground(new java.awt.Color(255, 255, 255));
        feed.setText(" ");

        cadastrarClienteBtn.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        cadastrarClienteBtn.setForeground(new java.awt.Color(255, 255, 255));
        cadastrarClienteBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/icons8-customer-24.png"))); // NOI18N
        cadastrarClienteBtn.setText("Cadastrar");
        cadastrarClienteBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        cadastrarClienteBtn.setContentAreaFilled(false);
        cadastrarClienteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrarClienteBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(userLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(cpf_c_f, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addComponent(userLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(nome_c_f, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel6Layout.createSequentialGroup()
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel6Layout.createSequentialGroup()
                                        .addGap(1, 1, 1)
                                        .addComponent(userLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(9, 9, 9))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                                        .addComponent(userLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(sexo_c_f, 0, 1, Short.MAX_VALUE)
                                    .addComponent(tel_c_f, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(75, 75, 75)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cadastrarClienteBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(loginLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(feed, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(31, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(loginLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(feed))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(nome_c_f, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(userLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(19, 19, 19)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(userLabel)
                            .addComponent(cpf_c_f, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(tel_c_f, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(userLabel2))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(sexo_c_f, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(userLabel3))
                        .addGap(37, 37, 37))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cadastrarClienteBtn)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Cadastro de clientes", jPanel3);

        jPanel17.setBackground(new java.awt.Color(204, 0, 0));

        nome_a_f.setBackground(new java.awt.Color(204, 0, 0));
        nome_a_f.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        nome_a_f.setForeground(new java.awt.Color(255, 255, 255));
        nome_a_f.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        nome_a_f.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                nome_a_fKeyReleased(evt);
            }
        });

        userLabel4.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        userLabel4.setForeground(new java.awt.Color(255, 255, 255));
        userLabel4.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        userLabel4.setText("Tipo:");

        userLabel5.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        userLabel5.setForeground(new java.awt.Color(255, 255, 255));
        userLabel5.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        userLabel5.setText("Nome:");

        userLabel6.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        userLabel6.setForeground(new java.awt.Color(255, 255, 255));
        userLabel6.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        userLabel6.setText("Sexo:");

        tipo_a_f.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        tipo_a_f.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Cão", "Gato" }));
        tipo_a_f.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        tipo_a_f.setOpaque(false);
        tipo_a_f.setRequestFocusEnabled(false);

        userLabel7.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        userLabel7.setForeground(new java.awt.Color(255, 255, 255));
        userLabel7.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        userLabel7.setText("Dono:");

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/icons8-german-shepherd-filled-100.png"))); // NOI18N

        loginLabel2.setFont(new java.awt.Font("Segoe UI Light", 0, 36)); // NOI18N
        loginLabel2.setForeground(new java.awt.Color(255, 255, 255));
        loginLabel2.setText("Novo animal: ");

        feed1.setFont(new java.awt.Font("Segoe UI Light", 0, 24)); // NOI18N
        feed1.setForeground(new java.awt.Color(255, 255, 255));
        feed1.setText(" ");

        cadastrarAnimalBtn.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        cadastrarAnimalBtn.setForeground(new java.awt.Color(255, 255, 255));
        cadastrarAnimalBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/icons8-german-shepherd-filled-24.png"))); // NOI18N
        cadastrarAnimalBtn.setText("Cadastrar");
        cadastrarAnimalBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        cadastrarAnimalBtn.setContentAreaFilled(false);
        cadastrarAnimalBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cadastrarAnimalBtnActionPerformed(evt);
            }
        });

        sexo_a_f.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        sexo_a_f.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Masculino", "Feminino", "Prefiro não responder" }));
        sexo_a_f.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        sexo_a_f.setOpaque(false);
        sexo_a_f.setRequestFocusEnabled(false);
        sexo_a_f.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sexo_a_fActionPerformed(evt);
            }
        });

        comboDonos.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        comboDonos.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "<jdbc>" }));
        comboDonos.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        comboDonos.setOpaque(false);
        comboDonos.setRequestFocusEnabled(false);
        comboDonos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboDonosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel17Layout = new javax.swing.GroupLayout(jPanel17);
        jPanel17.setLayout(jPanel17Layout);
        jPanel17Layout.setHorizontalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel17Layout.createSequentialGroup()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel17Layout.createSequentialGroup()
                                .addComponent(userLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(tipo_a_f, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel17Layout.createSequentialGroup()
                                .addComponent(userLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(nome_a_f, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(loginLabel2)
                        .addGap(18, 18, 18)
                        .addComponent(feed1, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addGap(13, 13, 13)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel17Layout.createSequentialGroup()
                                .addComponent(userLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(comboDonos, javax.swing.GroupLayout.PREFERRED_SIZE, 380, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel17Layout.createSequentialGroup()
                                .addComponent(userLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(sexo_a_f, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(80, 80, 80)
                                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(cadastrarAnimalBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
                .addContainerGap(28, Short.MAX_VALUE))
        );
        jPanel17Layout.setVerticalGroup(
            jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel17Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(loginLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(feed1))
                .addGap(18, 18, 18)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(nome_a_f, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(userLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(20, 20, 20)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(userLabel4)
                            .addComponent(tipo_a_f, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(sexo_a_f, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(userLabel6)))
                    .addGroup(jPanel17Layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cadastrarAnimalBtn)
                        .addGap(13, 13, 13)))
                .addGap(18, 18, 18)
                .addGroup(jPanel17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboDonos, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(userLabel7))
                .addGap(36, 36, 36))
        );

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel17, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel17, javax.swing.GroupLayout.PREFERRED_SIZE, 298, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Cadastro de animais", jPanel4);

        jPanel18.setBackground(new java.awt.Color(204, 0, 0));

        userLabel8.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        userLabel8.setForeground(new java.awt.Color(255, 255, 255));
        userLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        userLabel8.setText("Dia:");

        userLabel9.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        userLabel9.setForeground(new java.awt.Color(255, 255, 255));
        userLabel9.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        userLabel9.setText("Data:");

        userLabel10.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        userLabel10.setForeground(new java.awt.Color(255, 255, 255));
        userLabel10.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        userLabel10.setText("Serviço:");

        dia_r_f.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        dia_r_f.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado" }));
        dia_r_f.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        dia_r_f.setOpaque(false);
        dia_r_f.setRequestFocusEnabled(false);

        userLabel11.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        userLabel11.setForeground(new java.awt.Color(255, 255, 255));
        userLabel11.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        userLabel11.setText("Animal:");

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/icons8-atendimento-100.png"))); // NOI18N

        loginLabel3.setFont(new java.awt.Font("Segoe UI Light", 0, 36)); // NOI18N
        loginLabel3.setForeground(new java.awt.Color(255, 255, 255));
        loginLabel3.setText("Nova reserva:");

        reservarBtn.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        reservarBtn.setForeground(new java.awt.Color(255, 255, 255));
        reservarBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/icons8-relógio-26.png"))); // NOI18N
        reservarBtn.setText("Reservar");
        reservarBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        reservarBtn.setContentAreaFilled(false);
        reservarBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                reservarBtnActionPerformed(evt);
            }
        });

        servico_r_f.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        servico_r_f.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Banho", "Tosa", "Banho e Tosa", "Hospedagem", "Vacinação" }));
        servico_r_f.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        servico_r_f.setOpaque(false);
        servico_r_f.setRequestFocusEnabled(false);
        servico_r_f.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                servico_r_fActionPerformed(evt);
            }
        });

        comboAnimal.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        comboAnimal.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "<jdbc>" }));
        comboAnimal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        comboAnimal.setOpaque(false);
        comboAnimal.setRequestFocusEnabled(false);
        comboAnimal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboAnimalActionPerformed(evt);
            }
        });

        horario_r_f.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        horario_r_f.setForeground(new java.awt.Color(255, 255, 255));
        try {
            horario_r_f.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("##/##/####-##:##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        horario_r_f.setFont(new java.awt.Font("Segoe UI Light", 0, 18)); // NOI18N
        horario_r_f.setOpaque(false);
        horario_r_f.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                horario_r_fActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel18Layout = new javax.swing.GroupLayout(jPanel18);
        jPanel18.setLayout(jPanel18Layout);
        jPanel18Layout.setHorizontalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel18Layout.createSequentialGroup()
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(jPanel18Layout.createSequentialGroup()
                                    .addComponent(userLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(dia_r_f, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel18Layout.createSequentialGroup()
                                    .addComponent(userLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(horario_r_f, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel18Layout.createSequentialGroup()
                                    .addComponent(userLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(comboAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(jPanel18Layout.createSequentialGroup()
                                .addGap(1, 1, 1)
                                .addComponent(userLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(servico_r_f, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(74, 74, 74)
                        .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(reservarBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addGap(46, 46, 46)
                        .addComponent(loginLabel3)))
                .addContainerGap(82, Short.MAX_VALUE))
        );
        jPanel18Layout.setVerticalGroup(
            jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel18Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(loginLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(userLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(horario_r_f, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(22, 22, 22)
                        .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(userLabel8)
                            .addComponent(dia_r_f, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(servico_r_f, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(userLabel10))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(userLabel11)
                            .addComponent(comboAnimal, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(36, 36, 36))
                    .addGroup(jPanel18Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(reservarBtn)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Reservar horário", jPanel5);

        jPanel13.setBackground(new java.awt.Color(204, 0, 0));

        listarClientes_t.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome", "CPF", "Telefone", "Sexo"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(listarClientes_t);

        removerClienteBtn.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        removerClienteBtn.setForeground(new java.awt.Color(255, 255, 255));
        removerClienteBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/icons8-customer-24.png"))); // NOI18N
        removerClienteBtn.setText("Remover");
        removerClienteBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        removerClienteBtn.setContentAreaFilled(false);
        removerClienteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removerClienteBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGroup(jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addGap(454, 454, 454)
                        .addComponent(removerClienteBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE))
                    .addGroup(jPanel13Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane2)))
                .addContainerGap())
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 238, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(removerClienteBtn)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Listar: Clientes", jPanel9);

        jPanel19.setBackground(new java.awt.Color(204, 0, 0));

        listarAnimais_t.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Nome", "Tipo", "Sexo", "CPF do dono", "Identificador"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(listarAnimais_t);

        removerAnimalBtn.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        removerAnimalBtn.setForeground(new java.awt.Color(255, 255, 255));
        removerAnimalBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/icons8-german-shepherd-filled-24.png"))); // NOI18N
        removerAnimalBtn.setText("Remover");
        removerAnimalBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        removerAnimalBtn.setContentAreaFilled(false);
        removerAnimalBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removerAnimalBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel19Layout = new javax.swing.GroupLayout(jPanel19);
        jPanel19.setLayout(jPanel19Layout);
        jPanel19Layout.setHorizontalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel19Layout.createSequentialGroup()
                .addGroup(jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel19Layout.createSequentialGroup()
                        .addGap(454, 454, 454)
                        .addComponent(removerAnimalBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE))
                    .addGroup(jPanel19Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane3)))
                .addContainerGap())
        );
        jPanel19Layout.setVerticalGroup(
            jPanel19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel19Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 238, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(removerAnimalBtn)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel19, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Listar: Animais", jPanel10);

        jPanel20.setBackground(new java.awt.Color(204, 0, 0));

        listarReservas_t.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Horario", "Dia", "Serviço", "Animal (ID)", "CPF do cliente"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(listarReservas_t);

        removerHorarioBtn.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        removerHorarioBtn.setForeground(new java.awt.Color(255, 255, 255));
        removerHorarioBtn.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/icons8-relógio-26.png"))); // NOI18N
        removerHorarioBtn.setText("Liberar");
        removerHorarioBtn.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        removerHorarioBtn.setContentAreaFilled(false);
        removerHorarioBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removerHorarioBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel20Layout = new javax.swing.GroupLayout(jPanel20);
        jPanel20.setLayout(jPanel20Layout);
        jPanel20Layout.setHorizontalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel20Layout.createSequentialGroup()
                .addGroup(jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel20Layout.createSequentialGroup()
                        .addGap(454, 454, 454)
                        .addComponent(removerHorarioBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE))
                    .addGroup(jPanel20Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane4)))
                .addContainerGap())
        );
        jPanel20Layout.setVerticalGroup(
            jPanel20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel20Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 236, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(removerHorarioBtn)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel20, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("Reservas", jPanel11);

        jPanel16.setBackground(new java.awt.Color(204, 0, 0));

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagens/rsz_omdlogo.png"))); // NOI18N

        jLabel5.setFont(new java.awt.Font("Segoe UI Light", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("Petshop OhMyDog!® - O resto é kibe");

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Software de gerenciamento - V0.13 beta1 201709121108");

        jLabel7.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("Maria Fernanda (Database)");

        jLabel8.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("Carlos Henrique (Interface)");

        jLabel9.setFont(new java.awt.Font("Segoe UI Light", 1, 14)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel9.setText("Professores: Cledja Rolim (POO) / Fernando Antônio(BCDD) - 912");

        jLabel10.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel10.setText("Thayssa Melina (Documentação)");

        javax.swing.GroupLayout jPanel16Layout = new javax.swing.GroupLayout(jPanel16);
        jPanel16.setLayout(jPanel16Layout);
        jPanel16Layout.setHorizontalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, 544, Short.MAX_VALUE))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, 544, Short.MAX_VALUE))
                    .addGroup(jPanel16Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, 544, Short.MAX_VALUE)))
                .addContainerGap())
            .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        jPanel16Layout.setVerticalGroup(
            jPanel16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel16Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addGap(12, 12, 12)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addContainerGap())
        );

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel16, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        jTabbedPane1.addTab("<Sobre>", jPanel12);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 589, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(loginLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 294, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sairB))
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(loginLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 348, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(sairB, javax.swing.GroupLayout.PREFERRED_SIZE, 19, Short.MAX_VALUE)
                .addContainerGap())
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 0, 620, 470));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void sairBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sairBActionPerformed
        
        System.exit(0);
    }//GEN-LAST:event_sairBActionPerformed

    private void nome_c_fKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nome_c_fKeyReleased
        
        feed.setText(nome_c_f.getText());
    }//GEN-LAST:event_nome_c_fKeyReleased

    private void cadastrarClienteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastrarClienteBtnActionPerformed
        
        Cliente c = new Cliente(nome_c_f.getText(), cpf_c_f.getText(), tel_c_f.getText(), sexo_c_f.getSelectedItem().toString());
        ClienteDAO cdao = new ClienteDAO();
        cdao.adicionar(c);
        
        //atualizar comboBox de donos logo após a inserção
        atualizarListaDeClientes();
        resetar();
    }//GEN-LAST:event_cadastrarClienteBtnActionPerformed

    private void cadastrarAnimalBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cadastrarAnimalBtnActionPerformed
        String[] trimmed = comboDonos.getSelectedItem().toString().trim().split(" - ");
        Animal a = new Animal(nome_a_f.getText(), tipo_a_f.getSelectedItem().toString(), sexo_a_f.getSelectedItem().toString(), trimmed[1]);
        AnimalDAO adao = new AnimalDAO();
        adao.adicionar(a);
        atualizarListaDeAnimais();
        atualizarReservas();
        resetar();
    }//GEN-LAST:event_cadastrarAnimalBtnActionPerformed

    private void sexo_a_fActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sexo_a_fActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_sexo_a_fActionPerformed

    private void comboDonosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboDonosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboDonosActionPerformed

    private void reservarBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reservarBtnActionPerformed
        // TODO add your handling code here:
        String[] trimmed = comboAnimal.getSelectedItem().toString().trim().split(" - ");
        Atendimentos a = new Atendimentos(horario_r_f.getText(), dia_r_f.getSelectedItem().toString(), servico_r_f.getSelectedItem().toString(), Integer.parseInt(trimmed[0]), trimmed[2]);
        AtendimentoDAO atdao = new AtendimentoDAO();
        atdao.adicionar(a);
        atualizarReservas();
        resetar();
    }//GEN-LAST:event_reservarBtnActionPerformed

    private void servico_r_fActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_servico_r_fActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_servico_r_fActionPerformed

    private void comboAnimalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboAnimalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboAnimalActionPerformed

    private void nome_a_fKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_nome_a_fKeyReleased

    }//GEN-LAST:event_nome_a_fKeyReleased

    private void removerClienteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removerClienteBtnActionPerformed
        DefaultTableModel modelo_c = (DefaultTableModel) listarClientes_t.getModel();
        
        if(listarClientes_t.getSelectedRowCount() <= 0)
        {
            JOptionPane.showMessageDialog(this, "Você precisa selecionar um para remover!", "ERROR", 0);
        }
        else
        {
            int resposta = JOptionPane.showConfirmDialog( null,"Os animais deste cliente também serão removidos.\nDeseja continuar?", "AVISO!",JOptionPane.YES_NO_OPTION);

            switch(resposta)
            {
                case JOptionPane.YES_OPTION:
                    String sel = modelo_c.getValueAt(listarClientes_t.getSelectedRow(),1).toString();
                    ClienteDAO cdao = new ClienteDAO();
                    cdao.remover(sel);
                    atualizarListaDeClientes();
                    atualizarListaDeAnimais();
                    atualizarReservas();
                    break;
                default:
                    //nada acontece
            }
            
        }
        
    }//GEN-LAST:event_removerClienteBtnActionPerformed

    private void removerAnimalBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removerAnimalBtnActionPerformed
        DefaultTableModel modelo_a = (DefaultTableModel) listarAnimais_t.getModel();
        
        if(listarAnimais_t.getSelectedRowCount() <= 0)
        {
            JOptionPane.showMessageDialog(this, "Você precisa selecionar um para remover!", "ERROR", 0);
        }
        else
        {
                    String sel = modelo_a.getValueAt(listarAnimais_t.getSelectedRow(),4).toString();

                    AnimalDAO adao = new AnimalDAO();
                    adao.remover(sel);
                    atualizarListaDeClientes();
                    atualizarListaDeAnimais();
                    atualizarReservas();
        }
    }//GEN-LAST:event_removerAnimalBtnActionPerformed

    private void removerHorarioBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removerHorarioBtnActionPerformed
        // TODO add your handling code here:
        DefaultTableModel modelo_r = (DefaultTableModel) listarReservas_t.getModel();
        
        if(listarReservas_t.getSelectedRowCount() <= 0)
        {
            JOptionPane.showMessageDialog(this, "Você precisa selecionar um para remover!", "ERROR", 0);
        }
        else
        {
                    String sel = modelo_r.getValueAt(listarReservas_t.getSelectedRow(),0).toString();

                    AtendimentoDAO adao = new AtendimentoDAO();
                    adao.remover(sel);
                    atualizarListaDeClientes();
                    atualizarListaDeAnimais();
                    atualizarReservas();
        }
        
    }//GEN-LAST:event_removerHorarioBtnActionPerformed

    private void horario_r_fActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_horario_r_fActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_horario_r_fActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(C_Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(C_Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(C_Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(C_Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new C_Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cadastrarAnimalBtn;
    private javax.swing.JButton cadastrarClienteBtn;
    private javax.swing.JComboBox<String> comboAnimal;
    private javax.swing.JComboBox<String> comboDonos;
    private javax.swing.JFormattedTextField cpf_c_f;
    private javax.swing.JComboBox<String> dia_r_f;
    private javax.swing.JLabel feed;
    private javax.swing.JLabel feed1;
    private javax.swing.JFormattedTextField horario_r_f;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable listarAnimais_t;
    private javax.swing.JTable listarClientes_t;
    private javax.swing.JTable listarReservas_t;
    private javax.swing.JLabel loginLabel;
    private javax.swing.JLabel loginLabel1;
    private javax.swing.JLabel loginLabel2;
    private javax.swing.JLabel loginLabel3;
    private javax.swing.JTextField nome_a_f;
    private javax.swing.JTextField nome_c_f;
    private javax.swing.JButton removerAnimalBtn;
    private javax.swing.JButton removerClienteBtn;
    private javax.swing.JButton removerHorarioBtn;
    private javax.swing.JButton reservarBtn;
    private javax.swing.JButton sairB;
    private javax.swing.JComboBox<String> servico_r_f;
    private javax.swing.JComboBox<String> sexo_a_f;
    private javax.swing.JComboBox<String> sexo_c_f;
    private javax.swing.JFormattedTextField tel_c_f;
    private javax.swing.JComboBox<String> tipo_a_f;
    private javax.swing.JLabel userLabel;
    private javax.swing.JLabel userLabel1;
    private javax.swing.JLabel userLabel10;
    private javax.swing.JLabel userLabel11;
    private javax.swing.JLabel userLabel2;
    private javax.swing.JLabel userLabel3;
    private javax.swing.JLabel userLabel4;
    private javax.swing.JLabel userLabel5;
    private javax.swing.JLabel userLabel6;
    private javax.swing.JLabel userLabel7;
    private javax.swing.JLabel userLabel8;
    private javax.swing.JLabel userLabel9;
    // End of variables declaration//GEN-END:variables
}
