package DAO;

import Cadastros.Cliente;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ClienteDAO {
    private Connection conexao = null; 
    
    public ClienteDAO(){
        String url = "jdbc:mysql://localhost/db_ohmydog"; 
        String usuario = "root";
        String senha = "";
        
        try {
            conexao = DriverManager.getConnection(url, usuario, senha);
            System.out.println("Conexao com o banco de dados realizada com sucesso");
        } catch (SQLException e) {
            System.out.println("Erro na conexao com o banco: "+e);
        }
    }
    
    //metodo para adicionar o paciente no banco de dados
    public void adicionar(Cadastros.Cliente c){
        String insercao = "insert into clientes(nome, cpf, telefone, sexo) values (?,?,?,?)";
        PreparedStatement stmt;
        try{
            stmt = conexao.prepareStatement(insercao);
            stmt.setString(1, c.getNome());
            stmt.setString(2, c.getCpf());
            stmt.setString(3, c.getTelefone());
            stmt.setString(4, c.getSexo());
            
            stmt.execute();            
            System.out.println("Cliente cadastrado com sucesso.");

        }catch(SQLException e){
            System.out.println("Erro na insercao dos dados: "+e);
            JOptionPane.showMessageDialog(null, "Há um usuário com mesmo CPF já cadastrado!", "ERROR", 0);
        } 
    }
        
    public void remover(String str){
        String remocao;
        PreparedStatement stmt;
        try{
            remocao = "delete from atendimentos where fk_fk_cpf = ?";
            stmt = conexao.prepareStatement(remocao);
            stmt.setString(1, str);
            stmt.execute();
            
            remocao = "delete from animais where fk_cpf = ?";
            stmt = conexao.prepareStatement(remocao);
            stmt.setString(1, str);
            stmt.execute();
            
            
            remocao = "delete from clientes where cpf = ?";
            stmt = conexao.prepareStatement(remocao);
            stmt.setString(1, str);
            stmt.execute();
            


            System.out.println("Cliente removido com sucesso.");

        }catch(SQLException e){
            System.out.println("Erro na insercao dos dados: "+e);
        } 
    }
    
    
    public String[] listarNomes(){
        ArrayList<Cadastros.Cliente> client_a = new ArrayList<>();
        String consulta = "select * from clientes";
        try{
            PreparedStatement stmt = conexao.prepareStatement(consulta);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()){
                Cadastros.Cliente p = new Cadastros.Cliente(rs.getString("nome"), rs.getString("cpf"));
                client_a.add(p);
            }

        }catch(SQLException e){
            System.out.println("Erro na consulta dos dados: "+e);
        }
        String[] finalList = new String[client_a.size()];
        
        for(int i = 0 ; i < client_a.size() ; i ++)
        {
            finalList[i] = client_a.get(i).getNome() + " - " + client_a.get(i).getCpf();
        }
        
        return finalList;
    }
    
    
    
    
    //retornar, como ArrayList, todos os pacientes cadastrados
    public ArrayList<Cliente> consultarTodos(){
        ArrayList<Cadastros.Cliente> client_a = new ArrayList<>();
        String consulta = "select * from clientes";
        try{
            PreparedStatement stmt = conexao.prepareStatement(consulta);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()){
                Cadastros.Cliente p = new Cadastros.Cliente(rs.getString("nome"), rs.getString("cpf"), rs.getString("telefone"), rs.getString("sexo"));
                client_a.add(p);
            }

        }catch(SQLException e){
            System.out.println("Erro na consulta dos dados: "+e);
        }
        return client_a;
    }
}
