package DAO;

import java.sql.*;
import java.util.ArrayList;

public class UserDAO {
    private Connection conexao = null; 
    
    public UserDAO(){
        String url = "jdbc:mysql://localhost"; 
        String usuario = "root";
        String senha = "";
        try {
            conexao = DriverManager.getConnection(url, usuario, senha);
            System.out.println("Conexao com o banco de dados realizada com sucesso");
        } catch (SQLException e) {
            System.out.println("Erro na conexao com o banco: "+e);
        }
    }
    public UserDAO(boolean b){
        String url = "jdbc:mysql://localhost/db_ohmydog"; 
        String usuario = "root";
        String senha = "";
        try {
            conexao = DriverManager.getConnection(url, usuario, senha);
            System.out.println("Conexao com o banco de dados realizada com sucesso");
        } catch (SQLException e) {
            System.out.println("Erro na conexao com o banco: "+e);
        }
    }
    public void testCreateDatabase()
    {
        PreparedStatement stmt;
        try{
            stmt = conexao.prepareStatement("create database if not exists db_ohmydog;");
            stmt.execute();         
            stmt = conexao.prepareStatement("use db_ohmydog;");
            stmt.execute();         
            stmt = conexao.prepareStatement("create table if not exists endereco(id int not null auto_increment, cidade varchar(20) ,rua varchar(100), cep varchar(20), primary key (id));");
            stmt.execute();         
            stmt = conexao.prepareStatement("create table if not exists loginFuncionario(id int not null auto_increment, nome varchar(30), senha varchar(30), primary key (id));");
            stmt.execute();         
            stmt = conexao.prepareStatement("create table if not exists clientes (nome varchar(70), cpf varchar(20), telefone varchar(20), sexo varchar(30), primary key (cpf));");
            stmt.execute();         
            stmt = conexao.prepareStatement("create table if not exists petshop(nome varchar(100), cnpj varchar(20) not null, telefone varchar(15), fk_id_endereco int, fk_id_funcionario int , pk_id_cliente int, fk_cpf_cliente varchar(20), primary key(cnpj), foreign key (fk_id_endereco) references endereco(id), foreign key (fk_cpf_cliente) references clientes(cpf), foreign key (fk_id_funcionario) references loginFuncionario(id));");
            stmt.execute();         
            stmt = conexao.prepareStatement("create table if not exists animais(id int(11) not null auto_increment,nome varchar(30),tipo varchar(10),sexo varchar(20), fk_cpf varchar(20), primary key (id), foreign key(fk_cpf) references clientes(cpf));");
            stmt.execute();         
            stmt = conexao.prepareStatement("create table if not exists atendimentos(horario varchar(20),dia varchar(10),servico varchar(30),fk_id int(11), fk_cpf varchar(20),foreign key(fk_id) references animais(id), foreign key(fk_cpf) references clientes(cpf));");
            stmt.execute();                 
                  
            
            System.out.println("Verificação executada com sucesso.");

        }catch(SQLException e){
            System.out.println("Erro na insercao dos dados: "+e);
        } 
    }
    
    //metodo para adicionar o paciente no banco de dados
    public void adicionar(Auth.User p){
        String insercao = "insert into loginFuncionario(nome, senha) values (?,?)";
        PreparedStatement stmt = null;
        try{
            stmt = conexao.prepareStatement(insercao);
            stmt.setString(1, p.getUsuario());
            stmt.setString(2, p.getSenha());
            stmt.execute();            
            System.out.println("Usuario cadastrado com sucesso.");

        }catch(SQLException e){
            System.out.println("Erro na insercao dos dados: "+e);
        } 
    }

    //retornar, como ArrayList, todos os pacientes cadastrados
    public ArrayList<Auth.User> consultarTodos(){
        ArrayList<Auth.User> user_a = new ArrayList<>();
        String consulta = "select * from loginFuncionario";
        try{
            PreparedStatement stmt = conexao.prepareStatement(consulta);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()){
                Auth.User p = new Auth.User(rs.getString("nome"), rs.getString("senha"));
                user_a.add(p);
            }

        }catch(SQLException e){
            System.out.println("Erro na consulta dos dados: "+e);
        }
        return user_a;
    }
}
